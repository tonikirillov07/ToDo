package com.ds.todo.utils.actionListeners;

public interface IOnAction {
    void onAction();
}
